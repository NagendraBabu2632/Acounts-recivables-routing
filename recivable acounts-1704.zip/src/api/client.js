// src/api/client.js  –  Flask API connector
const BASE = 'http://172.16.0.177:5000/api'

async function req(path, opts = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...opts,
  })
  const data = await res.json()
  if (!res.ok || !data.success) throw new Error(data.error || 'Request failed')
  return data
}

export const api = {
  health:      ()           => req('/health'),
  portfolio:   ()           => req('/portfolio'),
  customer:    (id)         => req(`/customer/${id}`),
  worklist:    ()           => req('/quick/risk-worklist'),
  activityLog: (cid)        => req(`/activity-log${cid ? `?customer_id=${cid}` : ''}`),
  ptps:        ()           => req('/ptp'),

  chat: (query, customerId, history) =>
    req('/chat', {
      method: 'POST',
      body: JSON.stringify({ query, customer_id: customerId, history }),
    }),

  createPTP: (data) =>
    req('/ptp', { method: 'POST', body: JSON.stringify(data) }),

  creditHold: (customerId, reason) =>
    req('/credit-hold', {
      method: 'POST',
      body: JSON.stringify({ customer_id: customerId, reason }),
    }),
}
